# Install the driver that corresponds to the UART converter on your Arduino board (most often it is CH341)

PHOTOS

1. CH340/CH341: https://photos.app.goo.gl/UCcCsbAV8xmNvmeJ6

2. Atmega 16U2: https://photos.app.goo.gl/PJ5sAfesATTE11dLA

3. CP210x: https://photos.app.goo.gl/Jf8ZZ8DAEY4jRVrW6

4. FT230/FT232: https://photos.app.goo.gl/BjQz3aPjs5s8FrxRA , https://photos.app.goo.gl/RnQ98aeU4nT2xd99A
